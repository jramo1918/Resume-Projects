from django.shortcuts import render, redirect, HttpResponse
from .models import Network, TV_Show

# This will be the first page that holds: All Shows
def index(request):
    # This will give all the tv shows
    context = {"all_shows": TV_Show.objects.all()}
    return render(request, "tv_shows/index.html", context)

# this page will let you add a movie
def add_show(request):
    return render(request, "tv_shows/add_show.html")

def process_show(request):
    print(request.POST)
    tv_show = TV_Show.objects.create(
        title=request.POST['show_title'],
        release_date=request.POST['show_r_date'],
        description=request.POST['show_description'],
        network=Network.objects.create(name=request.POST['show_network'])
    )
    return redirect('/tv_show/' + str(tv_show.id))

def show_info(request, id):
    tv_show_obj = TV_Show.objects.get(id=id)
    context = {
        'displayed_show': tv_show_obj
    }
    return render(request, "tv_shows/show_info.html", context)

def display_edit_show(request, show_id):
    context = {
        'show': TV_Show.objects.get(id=show_id)
    }
    return render(request, "tv_shows/edit_show.html", context)

def edit_show(request, show_id):
    edit_show_obj = TV_Show.objects.get(id=show_id)
    edit_show_obj.title = request.POST['show_title']
    edit_show_obj.network = Network.objects.create(name=request.POST['show_network'])
    edit_show_obj.release_date = request.POST['show_r_date']
    edit_show_obj.description = request.POST['show_description']
    edit_show_obj.save()

    return redirect('/tv_show/' + str(show_id))

def delete_show(request, show_id):
    delete_show_obj = TV_Show.objects.get(id=show_id)
    delete_show_obj.delete()

    return redirect('/')
