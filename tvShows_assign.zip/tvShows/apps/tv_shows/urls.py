from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^tv_show/add$', views.add_show),
    url(r'^tv_show/add/process$', views.process_show),
    url(r'^tv_show/(?P<id>\d+$)', views.show_info),
    url(r'^tv_show/(?P<show_id>\d+)/edit$', views.display_edit_show),
    url(r'^tv_show/(?P<show_id>\d+)/update$', views.edit_show),
    url(r'^tv_show/(?P<show_id>\d+)/delete$', views.delete_show)
]