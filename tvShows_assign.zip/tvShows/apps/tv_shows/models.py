from django.db import models

# a netowkr can help several TV Shows, but
# a TV Show can onyl have one network

class Network(models.Model):
    name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class TV_Show(models.Model):
    title = models.CharField(max_length=255)
    release_date = models.CharField(max_length=255)
    description = models.TextField()
    network = models.ForeignKey(Network, related_name="tv_shows")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)



